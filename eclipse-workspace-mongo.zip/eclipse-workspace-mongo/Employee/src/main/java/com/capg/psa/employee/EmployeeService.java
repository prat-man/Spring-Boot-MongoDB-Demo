package com.capg.psa.employee;

import java.util.List;

public interface EmployeeService {
	
	public Employee find(int id);
	
	public List<Employee> findAll();
	
	public Employee create(Employee emp);

	public List<Employee> createAll(List<Employee> empList);
	
	public Employee update(Employee emp);

	public Employee delete(int id);

}
