package com.capg.psa.employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/Employee")
public class EmployeeController {

	@Autowired
	EmployeeService empService;

	/**
	 * Default portal
	 * @return String - Welcome message
	 */
	@GetMapping(value = "",
			produces = MediaType.APPLICATION_JSON_VALUE)
	public String get() {
		
		// display welcome message 
		return "Welcome to Employee Management System!";
		
	}
	
	@GetMapping(value = "/find/{id}",
			produces = MediaType.APPLICATION_JSON_VALUE)
	public Employee find(@PathVariable int id) {
		
		// find employee by id
		return empService.find(id);
		
	}
	
	@GetMapping(value = "/findall",
			produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Employee> find() {
		
		// find employee by id
		return empService.findAll();
		
	}
	
	/**
	 * Save Employee object
	 * @param employee - Employee object to be saved
	 * @return Saved Employee object
	 * @throws Exception 
	 */
	@PostMapping(value = "/create",
			produces = MediaType.APPLICATION_JSON_VALUE,
			consumes = MediaType.APPLICATION_JSON_VALUE)
	public Employee create(@RequestBody Employee employee) {
		
		// save the employee object and return saved object
		return empService.create(employee);
		
	}
	
	@PostMapping(value = "/createall",
			produces = MediaType.APPLICATION_JSON_VALUE,
			consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<Employee> createAll(@RequestBody List<Employee> empList) {
		
		// save all employee objects and return saved object list
		return empService.createAll(empList);
		
	}
	
	@PutMapping(value = "/update",
			produces = MediaType.APPLICATION_JSON_VALUE,
			consumes = MediaType.APPLICATION_JSON_VALUE)
	public Employee update(@RequestBody Employee employee) {
		
		// save the employee object and return saved object
		return empService.update(employee);
		
	}
	
	@DeleteMapping(value = "/delete/{id}",
			produces = MediaType.APPLICATION_JSON_VALUE)
	public Employee update(@PathVariable int id) {
		
		// save the employee object and return saved object
		return empService.delete(id);
		
	}

}
