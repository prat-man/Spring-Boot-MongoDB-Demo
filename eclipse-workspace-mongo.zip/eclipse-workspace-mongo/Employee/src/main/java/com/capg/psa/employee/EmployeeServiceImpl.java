package com.capg.psa.employee;

import java.security.InvalidParameterException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	EmployeeRepository empRepo;
	
	@Override
	public Employee find(int id) {
		Optional<Employee> savedEmpOp = empRepo.findById(id);
		
		if (savedEmpOp.isPresent()) {
			return savedEmpOp.get();
		}
		
		throw new InvalidParameterException("Employee does not exist!");
	}
	
	@Override
	public List<Employee> findAll() {
		// find all employees
		return empRepo.findAll();
	}
	
	@Override
	public Employee create(Employee emp) {
		Optional<Employee> savedEmpOp = empRepo.findById(emp.getId());
		
		if (!savedEmpOp.isPresent()) {
			// save employee
			return empRepo.save(emp);
		}
		
		throw new InvalidParameterException("Employee already exists!");
	}
	
	@Override
	public List<Employee> createAll(List<Employee> empList) {
		// save all employees
		return empRepo.saveAll(empList);
	}

	@Override
	public Employee update(Employee emp) {
		Optional<Employee> savedEmpOp = empRepo.findById(emp.getId());
		
		if (savedEmpOp.isPresent()) {
			Employee savedEmp = savedEmpOp.get();
			
			if (emp.getFname() != null) savedEmp.setFname(emp.getFname());
			if (emp.getFname() != null) savedEmp.setFname(emp.getFname());
			if (emp.getDepartment() != null && emp.getDepartment().getName() != null) savedEmp.getDepartment().setName(emp.getDepartment().getName());
			if (emp.getDepartment() != null && emp.getDepartment().getLocation() != null) savedEmp.getDepartment().setLocation(emp.getDepartment().getLocation());
			
			return empRepo.save(savedEmp);
		}
		
		throw new InvalidParameterException("Employee does not exist!");
	}

	@Override
	public Employee delete(int id) {
		Optional<Employee> savedEmpOp = empRepo.findById(id);
		
		if (savedEmpOp.isPresent()) {
			Employee savedEmp = savedEmpOp.get();
			
			empRepo.delete(savedEmp);
			
			return savedEmp;
		}
		
		throw new InvalidParameterException("Employee does not exist!");
		
	}

}
